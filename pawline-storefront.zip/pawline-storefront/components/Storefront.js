'use client';

import { useEffect, useMemo, useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Menu, Search, ShoppingBag, X, ChevronRight, ShieldCheck, Truck, Heart } from 'lucide-react';

const SHOP_DOMAIN = 'https://pawline-shop.de';

function price(product) {
  const values = (product.variants || []).map((variant) => Number(variant.price));
  const min = Math.min(...values);
  const max = Math.max(...values);
  const fmt = (v) => new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }).format(v);
  return min === max ? fmt(min) : `ab ${fmt(min)}`;
}

function inferCategory(product) {
  const text = `${product.title} ${product.body_html || ''}`.toLowerCase();
  if (/katze|kratz|kitten/.test(text)) return 'Katzen';
  if (/hund|leine|halsband|geschirr/.test(text)) return 'Hunde';
  return 'Lieblingsstücke';
}

export default function Storefront() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('Alle');
  const [menuOpen, setMenuOpen] = useState(false);
  const [cart, setCart] = useState([]);
  const [cartOpen, setCartOpen] = useState(false);

  useEffect(() => {
    fetch('/api/products')
      .then((response) => response.json())
      .then((data) => setProducts(data.products || []))
      .finally(() => setLoading(false));
    const saved = localStorage.getItem('pawline-cart');
    if (saved) setCart(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem('pawline-cart', JSON.stringify(cart));
  }, [cart]);

  const filtered = useMemo(() => products.filter((product) => {
    const matchesQuery = product.title.toLowerCase().includes(query.toLowerCase());
    const matchesCategory = category === 'Alle' || inferCategory(product) === category;
    return matchesQuery && matchesCategory;
  }), [products, query, category]);

  function addToCart(product) {
    const variant = product.variants?.find((item) => item.available) || product.variants?.[0];
    if (!variant) return;
    setCart((current) => {
      const existing = current.find((item) => item.variantId === variant.id);
      if (existing) return current.map((item) => item.variantId === variant.id ? { ...item, quantity: item.quantity + 1 } : item);
      return [...current, {
        variantId: variant.id,
        title: product.title,
        variantTitle: variant.title,
        price: Number(variant.price),
        quantity: 1,
        image: product.images?.[0]?.src
      }];
    });
    setCartOpen(true);
  }

  function checkout() {
    if (!cart.length) return;
    const items = cart.map((item) => `${item.variantId}:${item.quantity}`).join(',');
    window.location.href = `${SHOP_DOMAIN}/cart/${items}`;
  }

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const count = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <main>
      <div className="announcement">Kostenloser Versand ab 69 € · Sichere Zahlung · Mit Liebe ausgewählt</div>
      <header className="header">
        <button className="iconButton mobileOnly" onClick={() => setMenuOpen(true)} aria-label="Menü öffnen"><Menu /></button>
        <Link href="/" className="logo">PAWLINE<span>.</span></Link>
        <nav className="desktopNav">
          {['Alle', 'Hunde', 'Katzen', 'Lieblingsstücke'].map((item) => (
            <button key={item} onClick={() => setCategory(item)} className={category === item ? 'active' : ''}>{item}</button>
          ))}
        </nav>
        <div className="headerActions">
          <label className="searchBox"><Search size={18}/><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Produkte suchen" /></label>
          <button className="iconButton cartButton" onClick={() => setCartOpen(true)} aria-label="Warenkorb"><ShoppingBag />{count > 0 && <span>{count}</span>}</button>
        </div>
      </header>

      <section className="hero">
        <div className="heroCopy">
          <span className="eyebrow">Für eure schönsten gemeinsamen Momente</span>
          <h1>Lieblingsstücke für <em>Fellnasen.</em></h1>
          <p>Hochwertige Accessoires, gemütliche Schlafplätze und besondere Alltagsbegleiter für Hunde und Katzen.</p>
          <a href="#produkte" className="primaryButton">Kollektion entdecken <ChevronRight size={18}/></a>
        </div>
        <div className="heroVisual">
          <div className="heroCard"><Heart fill="currentColor"/><strong>Mit Liebe ausgewählt</strong><span>Für Komfort, Freude und gemeinsame Zeit.</span></div>
        </div>
      </section>

      <section className="trustRow">
        <div><ShieldCheck/><span><strong>Sicher einkaufen</strong>Geschützter Shopify-Checkout</span></div>
        <div><Truck/><span><strong>Schneller Versand</strong>Zuverlässig zu dir nach Hause</span></div>
        <div><Heart/><span><strong>Für Tierfreunde</strong>Sorgfältig ausgewähltes Sortiment</span></div>
      </section>

      <section className="shopSection" id="produkte">
        <div className="sectionHeading">
          <div><span className="eyebrow">Pawline Kollektion</span><h2>Entdecke unsere Lieblingsstücke</h2></div>
          <span>{filtered.length} Produkte</span>
        </div>
        <div className="categoryPills">
          {['Alle', 'Hunde', 'Katzen', 'Lieblingsstücke'].map((item) => <button key={item} onClick={() => setCategory(item)} className={category === item ? 'selected' : ''}>{item}</button>)}
        </div>
        {loading ? <div className="loading">Produkte werden geladen …</div> : (
          <div className="productGrid">
            {filtered.map((product) => (
              <article className="productCard" key={product.id}>
                <Link href={`/products/${product.handle}`} className="imageWrap">
                  {product.images?.[0]?.src && <Image src={product.images[0].src} alt={product.title} fill sizes="(max-width: 700px) 50vw, 25vw" />}
                  <span className="badge">{inferCategory(product)}</span>
                </Link>
                <div className="productInfo">
                  <Link href={`/products/${product.handle}`}><h3>{product.title}</h3></Link>
                  <div className="productBottom"><strong>{price(product)}</strong><button onClick={() => addToCart(product)}>Hinzufügen</button></div>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>

      <footer><Link href="/" className="logo light">PAWLINE<span>.</span></Link><p>Besondere Produkte für besondere Begleiter.</p><div><a href={`${SHOP_DOMAIN}/pages/impressum`}>Impressum</a><a href={`${SHOP_DOMAIN}/pages/datenschutz`}>Datenschutz</a><a href={`${SHOP_DOMAIN}/policies/terms-of-service`}>AGB</a></div></footer>

      {menuOpen && <div className="overlay" onClick={() => setMenuOpen(false)}><aside className="sideMenu" onClick={(e) => e.stopPropagation()}><button className="close" onClick={() => setMenuOpen(false)}><X/></button><div className="logo">PAWLINE<span>.</span></div>{['Alle', 'Hunde', 'Katzen', 'Lieblingsstücke'].map((item) => <button key={item} onClick={() => {setCategory(item); setMenuOpen(false);}}>{item}<ChevronRight/></button>)}</aside></div>}
      {cartOpen && <div className="overlay" onClick={() => setCartOpen(false)}><aside className="cartDrawer" onClick={(e) => e.stopPropagation()}><div className="drawerHead"><h2>Dein Warenkorb</h2><button onClick={() => setCartOpen(false)}><X/></button></div><div className="cartItems">{cart.length === 0 ? <p className="empty">Dein Warenkorb ist noch leer.</p> : cart.map((item) => <div className="cartItem" key={item.variantId}>{item.image && <img src={item.image} alt=""/>}<div><strong>{item.title}</strong><small>{item.variantTitle}</small><div className="quantity"><button onClick={() => setCart(c => c.map(i => i.variantId === item.variantId ? {...i, quantity: Math.max(1, i.quantity - 1)} : i))}>−</button><span>{item.quantity}</span><button onClick={() => setCart(c => c.map(i => i.variantId === item.variantId ? {...i, quantity: i.quantity + 1} : i))}>+</button></div></div><b>{new Intl.NumberFormat('de-DE',{style:'currency',currency:'EUR'}).format(item.price * item.quantity)}</b></div>)}</div><div className="cartFooter"><div><span>Zwischensumme</span><strong>{new Intl.NumberFormat('de-DE',{style:'currency',currency:'EUR'}).format(total)}</strong></div><button onClick={checkout} disabled={!cart.length}>Sicher zur Kasse</button><small>Du wirst zum geschützten Shopify-Checkout weitergeleitet.</small></div></aside></div>}
    </main>
  );
}

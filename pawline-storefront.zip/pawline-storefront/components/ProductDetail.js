'use client';
import { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { ArrowLeft, Check, ShieldCheck, Truck } from 'lucide-react';

export default function ProductDetail({ product }) {
  const available = product.variants.filter((v) => v.available);
  const [variantId, setVariantId] = useState((available[0] || product.variants[0])?.id);
  const [image, setImage] = useState(product.images?.[0]?.src);
  const variant = product.variants.find((v) => v.id === Number(variantId)) || product.variants[0];
  const price = new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }).format(Number(variant?.price || 0));
  const checkout = () => { window.location.href = `https://pawline-shop.de/cart/${variant.id}:1`; };
  return <main className="detailPage"><header className="simpleHeader"><Link href="/"><ArrowLeft/> Zurück</Link><Link href="/" className="logo">PAWLINE<span>.</span></Link><div/></header><section className="detailGrid"><div className="gallery"><div className="mainImage">{image && <Image src={image} alt={product.title} fill sizes="60vw"/>}</div><div className="thumbs">{product.images.map((img) => <button key={img.id} onClick={() => setImage(img.src)} className={image === img.src ? 'activeThumb' : ''}><img src={img.src} alt=""/></button>)}</div></div><div className="detailCopy"><span className="eyebrow">Pawline Lieblingsstück</span><h1>{product.title}</h1><div className="detailPrice">{price}</div>{product.options?.[0] && <label className="variantLabel">{product.options[0].name}<select value={variantId} onChange={(e) => setVariantId(e.target.value)}>{product.variants.map((v) => <option value={v.id} key={v.id} disabled={!v.available}>{v.title}{!v.available ? ' – Ausverkauft' : ''}</option>)}</select></label>}<button className="buyButton" onClick={checkout} disabled={!variant?.available}>Jetzt sicher kaufen</button><div className="benefits"><span><Check/> Sofort verfügbar</span><span><ShieldCheck/> Sicherer Checkout</span><span><Truck/> Zuverlässiger Versand</span></div><div className="description" dangerouslySetInnerHTML={{__html: product.body_html}}/></div></section></main>;
}
